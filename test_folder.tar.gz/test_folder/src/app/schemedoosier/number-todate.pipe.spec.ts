import { NumberTodatePipe } from './number-todate.pipe';

describe('NumberTodatePipe', () => {
  it('create an instance', () => {
    const pipe = new NumberTodatePipe();
    expect(pipe).toBeTruthy();
  });
});
