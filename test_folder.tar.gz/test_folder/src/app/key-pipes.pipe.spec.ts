import { KeyPipesPipe } from './key-pipes.pipe';

describe('KeyPipesPipe', () => {
  it('create an instance', () => {
    const pipe = new KeyPipesPipe();
    expect(pipe).toBeTruthy();
  });
});
