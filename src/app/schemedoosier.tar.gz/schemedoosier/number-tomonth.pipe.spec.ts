import { NumberTomonthPipe } from './number-tomonth.pipe';

describe('NumberTomonthPipe', () => {
  it('create an instance', () => {
    const pipe = new NumberTomonthPipe();
    expect(pipe).toBeTruthy();
  });
});
