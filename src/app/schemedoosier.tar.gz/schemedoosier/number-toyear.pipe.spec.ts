import { NumberToyearPipe } from './number-toyear.pipe';

describe('NumberToyearPipe', () => {
  it('create an instance', () => {
    const pipe = new NumberToyearPipe();
    expect(pipe).toBeTruthy();
  });
});
