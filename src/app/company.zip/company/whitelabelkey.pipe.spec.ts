import { WhitelabelkeyPipe } from './whitelabelkey.pipe';

describe('WhitelabelkeyPipe', () => {
  it('create an instance', () => {
    const pipe = new WhitelabelkeyPipe();
    expect(pipe).toBeTruthy();
  });
});
